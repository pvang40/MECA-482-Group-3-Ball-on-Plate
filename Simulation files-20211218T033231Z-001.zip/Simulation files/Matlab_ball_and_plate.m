clear; clc; close all;
coppelia=remApi('remoteApi');
coppelia.simxFinish(-1);
clientID=coppelia.simxStart('127.0.0.1',19999,true,true,5000,5);
open_system("meca482.slx")
    
    % PID gains
     P=0.0225594367101972;
     I=0.000899688669450741;
     D=0.158914516635466;

if (clientID>-1)  
     disp('Connected to remote API server');
     disp('Starting Simulation')
     set_param('meca482','SimulationCommand','start') 

     % Simulation joints
     h=[0,0];
        [r,h(1)]=coppelia.simxGetObjectHandle(clientID,'Servo_X',coppelia.simx_opmode_blocking);
        [r,h(2)]=coppelia.simxGetObjectHandle(clientID,'Servo_Y',coppelia.simx_opmode_blocking);
       
     while true
     [res,retInts,retFloats,retStrings,retBuffer]=coppelia.simxCallScriptFunction(clientID,'Cam',coppelia.sim_scripttype_childscript,'CoordCalc',[],[],[],'',coppelia.simx_opmode_blocking);
     xcoord=retFloats(1);
     ycoord=retFloats(2);

     r_matx=xcoord;
     set_param('meca482/Input_X','Value',num2str(r_matx));
     pause(.005);
    
     r_maty=ycoord;
     set_param('meca482/Input_Y','Value',num2str(r_maty));
     pause(.005);
    
     thetaX=get_param('meca482/Out_X','RuntimeObject');
     angleX= (thetaX.InputPort(1).Data*10000);
    
     thetaY=get_param('meca482/Out_Y','RuntimeObject');
     angleY= (thetaY.InputPort(1).Data*10000);
     
     coppelia.simxSetJointTargetPosition(clientID,h(1),angleX,coppelia.simx_opmode_streaming);
     coppelia.simxSetJointTargetPosition(clientID,h(2),angleY,coppelia.simx_opmode_streaming);
     
     
     end
else
      disp('Failed connecting to remote API server');
end
coppelia.delete(); % call the destructor!

close_system("meca482.slx")

disp('Program ended');